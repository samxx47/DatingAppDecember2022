﻿namespace API.DTOs
{
    public class MemberUpdateDto
    {
        public string Introduction { get; set; } = String.Empty;
        public string Interests { get; set; } = String.Empty;
        public string City { get; set; } = String.Empty;
        public string Country { get; set; } = String.Empty;
    }
}
